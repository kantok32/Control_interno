import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config({ path: join(__dirname, '../../config.env') });

const pool = mysql.createPool({
  host: process.env.DB_HOST || '192.140.56.40',
  user: process.env.DB_USER || 'invers26_claudio_m1',
  password: process.env.DB_PASSWORD || 'Ni.co0189',
  database: process.env.DB_NAME || 'invers26_ERP'
});

async function checkDocsTable() {
  try {
    console.log('🔍 Verificando tabla documentos_personal...');
    
    const [tables] = await pool.query(`
      SELECT TABLE_NAME 
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'documentos_personal'
    `, [process.env.DB_NAME || 'invers26_ERP']);
    
    if (tables.length === 0) {
      console.log('❌ La tabla documentos_personal NO existe');
      console.log('📝 Creando tabla documentos_personal...');
      
      await pool.query(`
        CREATE TABLE documentos_personal (
          id INT AUTO_INCREMENT PRIMARY KEY,
          personal_id INT NOT NULL,
          nombre VARCHAR(255) NOT NULL,
          descripcion TEXT,
          ruta_archivo VARCHAR(500) NOT NULL,
          fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (personal_id) REFERENCES personal_documentacion(id) ON DELETE CASCADE
        )
      `);
      
      console.log('✅ Tabla documentos_personal creada exitosamente');
    } else {
      console.log('✅ La tabla documentos_personal existe');
      
      // Mostrar estructura
      const [columns] = await pool.query(`
        SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'documentos_personal'
        ORDER BY ORDINAL_POSITION
      `, [process.env.DB_NAME || 'invers26_ERP']);
      
      console.log('📋 Estructura de documentos_personal:');
      columns.forEach(col => {
        console.log(`  - ${col.COLUMN_NAME}: ${col.DATA_TYPE} ${col.IS_NULLABLE === 'NO' ? '(NOT NULL)' : '(NULL)'}`);
      });
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await pool.end();
  }
}

checkDocsTable(); 