import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config({ path: join(__dirname, '../../config.env') });

const pool = mysql.createPool({
  host: process.env.DB_HOST || '192.140.56.40',
  user: process.env.DB_USER || 'invers26_claudio_m1',
  password: process.env.DB_PASSWORD || 'Ni.co0189',
  database: process.env.DB_NAME || 'invers26_ERP'
});

async function fixDocsTable() {
  try {
    console.log('🔧 Actualizando tabla documentos_personal...');
    
    // Verificar si existen las columnas necesarias
    const [columns] = await pool.query(`
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'documentos_personal'
    `, [process.env.DB_NAME || 'invers26_ERP']);
    
    const existingColumns = columns.map(col => col.COLUMN_NAME);
    console.log('Columnas existentes:', existingColumns);
    
    // Agregar columnas faltantes
    if (!existingColumns.includes('personal_id')) {
      console.log('➕ Agregando columna personal_id...');
      await pool.query('ALTER TABLE documentos_personal ADD COLUMN personal_id INT NOT NULL FIRST');
    }
    
    if (!existingColumns.includes('nombre')) {
      console.log('➕ Agregando columna nombre...');
      await pool.query('ALTER TABLE documentos_personal ADD COLUMN nombre VARCHAR(255) NOT NULL AFTER personal_id');
    }
    
    if (!existingColumns.includes('descripcion')) {
      console.log('➕ Agregando columna descripcion...');
      await pool.query('ALTER TABLE documentos_personal ADD COLUMN descripcion TEXT AFTER nombre');
    }
    
    // Agregar foreign key si no existe
    try {
      await pool.query(`
        ALTER TABLE documentos_personal 
        ADD CONSTRAINT fk_documentos_personal 
        FOREIGN KEY (personal_id) REFERENCES personal_documentacion(id) ON DELETE CASCADE
      `);
      console.log('🔗 Foreign key agregada');
    } catch (error) {
      if (error.code === 'ER_DUP_KEYNAME') {
        console.log('🔗 Foreign key ya existe');
      } else {
        throw error;
      }
    }
    
    console.log('✅ Tabla documentos_personal actualizada correctamente');
    
    // Mostrar estructura final
    const [finalColumns] = await pool.query(`
      SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'documentos_personal'
      ORDER BY ORDINAL_POSITION
    `, [process.env.DB_NAME || 'invers26_ERP']);
    
    console.log('📋 Estructura final de documentos_personal:');
    finalColumns.forEach(col => {
      console.log(`  - ${col.COLUMN_NAME}: ${col.DATA_TYPE} ${col.IS_NULLABLE === 'NO' ? '(NOT NULL)' : '(NULL)'}`);
    });
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await pool.end();
  }
}

fixDocsTable(); 