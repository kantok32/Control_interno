import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config({ path: join(__dirname, '../../config.env') });

const pool = mysql.createPool({
  host: process.env.DB_HOST || '192.140.56.40',
  user: process.env.DB_USER || 'invers26_claudio_m1',
  password: process.env.DB_PASSWORD || 'Ni.co0189',
  database: process.env.DB_NAME || 'invers26_ERP'
});

async function checkPersonalTable() {
  try {
    console.log('🔍 Verificando tabla personal_documentacion...');
    
    // Verificar si la tabla existe
    const [tables] = await pool.query(`
      SELECT TABLE_NAME 
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'personal_documentacion'
    `, [process.env.DB_NAME || 'invers26_ERP']);
    
    if (tables.length === 0) {
      console.log('❌ La tabla personal_documentacion NO existe');
      console.log('📝 Creando tabla personal_documentacion...');
      
      await pool.query(`
        CREATE TABLE personal_documentacion (
          id INT AUTO_INCREMENT PRIMARY KEY,
          nombre VARCHAR(255) NOT NULL,
          cargo VARCHAR(255),
          departamento VARCHAR(255),
          fecha_ingreso DATE,
          estado ENUM('activo', 'inactivo') DEFAULT 'activo',
          fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
      `);
      
      console.log('✅ Tabla personal_documentacion creada exitosamente');
      
      // Insertar algunos datos de ejemplo
      await pool.query(`
        INSERT INTO personal_documentacion (nombre, cargo, departamento, fecha_ingreso) VALUES
        ('Juan Pérez', 'Abogado', 'Legal', '2023-01-15'),
        ('María González', 'Asistente Legal', 'Legal', '2023-02-20'),
        ('Carlos Rodríguez', 'Secretario', 'Administración', '2023-03-10')
      `);
      
      console.log('✅ Datos de ejemplo insertados');
    } else {
      console.log('✅ La tabla personal_documentacion existe');
    }
    
    // Verificar estructura de la tabla
    const [columns] = await pool.query(`
      SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'personal_documentacion'
      ORDER BY ORDINAL_POSITION
    `, [process.env.DB_NAME || 'invers26_ERP']);
    
    console.log('📋 Estructura de la tabla:');
    columns.forEach(col => {
      console.log(`  - ${col.COLUMN_NAME}: ${col.DATA_TYPE} ${col.IS_NULLABLE === 'NO' ? '(NOT NULL)' : '(NULL)'}`);
    });
    
    // Verificar si hay datos
    const [count] = await pool.query('SELECT COUNT(*) as total FROM personal_documentacion');
    console.log(`📊 Total de registros: ${count[0].total}`);
    
    // Verificar tabla documentos_personal
    console.log('\n🔍 Verificando tabla documentos_personal...');
    
    const [docTables] = await pool.query(`
      SELECT TABLE_NAME 
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'documentos_personal'
    `, [process.env.DB_NAME || 'invers26_ERP']);
    
    if (docTables.length === 0) {
      console.log('❌ La tabla documentos_personal NO existe');
      console.log('📝 Creando tabla documentos_personal...');
      
      await pool.query(`
        CREATE TABLE documentos_personal (
          id INT AUTO_INCREMENT PRIMARY KEY,
          personal_id INT NOT NULL,
          nombre VARCHAR(255) NOT NULL,
          descripcion TEXT,
          ruta_archivo VARCHAR(500) NOT NULL,
          fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (personal_id) REFERENCES personal_documentacion(id) ON DELETE CASCADE
        )
      `);
      
      console.log('✅ Tabla documentos_personal creada exitosamente');
    } else {
      console.log('✅ La tabla documentos_personal existe');
    }
    
    console.log('\n🎉 Verificación completada');
    
  } catch (error) {
    console.error('❌ Error durante la verificación:', error);
  } finally {
    await pool.end();
  }
}

checkPersonalTable(); 